# Quick Bill — Retail Billing PWA

Offline-first retail billing web app for Arun Traders. Installable PWA, no backend required — all data lives in the browser's IndexedDB on the device.

## 1. Folder structure

```
quickbill/
├── index.html          # All screens (Quick Bill, Inventory, Customers, Reports,
│                        #  Bill History, Printer Setup, Backup, Login) + modals
├── manifest.json        # PWA manifest (installable, standalone, orange theme)
├── sw.js                 # Service worker — caches app shell for offline use
├── css/
│   └── style.css         # Dark theme, matches reference layout
├── js/
│   ├── db.js              # IndexedDB schema + generic CRUD + backup/restore
│   ├── auth.js            # Admin/Staff PIN login
│   ├── billing.js         # Cart, save/void/return bill, stock deduction, reports
│   ├── printer.js         # ESC/POS builder + Bluetooth/bridge print adapter
│   ├── export.js          # CSV / Excel / PDF export helpers
│   ├── app.js              # UI wiring for every screen
│   └── sample-data.js      # Optional demo inventory/customers (not auto-loaded)
└── icons/                 # App icons (192/512, regular + maskable)
```

Everything is vanilla HTML/CSS/JS — no build step, no bundler required.

## 2. IndexedDB schema (`quickbill_db`, version 1)

| Store        | Key            | Indexes                              | Purpose |
|--------------|----------------|---------------------------------------|---------|
| `items`      | `id` (auto)    | barcode, name, category               | Inventory |
| `customers`  | `id` (auto)    | phone, name                           | Customer database |
| `bills`      | `id` (auto)    | billNo (unique), date, customerId, status, paymentStatus | Sales bills |
| `billItems`  | `id` (auto)    | billId, itemId, date                  | Denormalized line items for fast reports |
| `payments`   | `id` (auto)    | billId, customerId, date              | Payments against bills/customer balance |
| `users`      | `id` (auto)    | username (unique)                     | Admin/Staff login |
| `settings`   | `key`          | —                                      | Shop info, bill numbering, printer pairing |
| `stockLedger`| `id` (auto)    | itemId, date                          | Stock in/out audit trail (sale/void/return) |

See `js/sample-data.js` for example row shapes (`ITEM_MODEL_EXAMPLE`, `CUSTOMER_MODEL_EXAMPLE`, `BILL_MODEL_EXAMPLE`).

## 3. Billing logic (`js/billing.js`)

- `Billing.cart` holds in-progress line items (`{ itemId, name, qty, rate, total }`).
- `addLine` / `updateLine` / `removeLine` / `clearCart` manage the cart.
- `saveBill()` — writes the bill, denormalized `billItems`, deducts `items.stock`, logs a `stockLedger` entry, and updates customer balance if unpaid/partial.
- `voidBill()` — marks a bill void and restocks all lines.
- `returnBill()` — partial/full return; restocks returned quantities and records a `returnAmount`.
- `editBill()` / `deleteBill()` — admin corrections.
- Reporting: `dailySales`, `monthlySales`, `itemWiseSales`, `profitReport` (revenue vs. `purchaseRate` cost).

## 4. Printer integration (`js/printer.js`)

Two-tier adapter, since Web Bluetooth isn't available everywhere (notably iOS/Safari):

1. **Web Bluetooth (primary):** `Printer.connect()` pairs with a BLE ESC/POS printer via `navigator.bluetooth.requestDevice`, writes chunked byte buffers to the printer's write characteristic.
2. **Bridge-friendly fallback:** if Web Bluetooth is unsupported or the write fails, `printViaBridge()`:
   - calls `window.AndroidPrintBridge.print(base64)` if the app is wrapped in a WebView that injects that interface,
   - otherwise attempts a `rawbt:` intent URL (works with the popular free RawBT Android print-bridge app),
   - otherwise downloads the raw `.escpos` byte file so it can be sent by any external print utility.

`buildReceiptBytes()` formats an ESC/POS receipt with a paper-width setting from 50 mm to 100 mm. The selected width adjusts the tabular columns for the header, bill number/date, item rows, totals, and paper cut command. Swap `SERVICE_UUID`/`CHAR_UUID` for your specific printer model if it differs from the generic serial-profile UUIDs used here.

## 5. Sample data models

See `js/sample-data.js` — includes 5 sample inventory items, 3 sample customers, and one example bill shape, plus a `loadSampleData()` helper you can run from the console for demos.

## 6. Deployment steps

**Any static host works** since this is a pure client-side PWA:

1. Generate real icons (replace the placeholder `icons/*.png`) at 192×192 and 512×512, plus maskable variants.
2. Host the `quickbill/` folder as-is on any static file host:
   - **GitHub Pages:** push to a repo, enable Pages on the branch/folder.
   - **Netlify / Vercel:** drag-and-drop the folder or connect the repo; no build command needed.
   - **Firebase Hosting:** `firebase init hosting` → set public dir to `quickbill` → `firebase deploy`.
   - **Your own server:** serve over **HTTPS** (required for service workers + Web Bluetooth) — e.g. Nginx serving the folder directly.
3. Confirm `manifest.json` and `sw.js` are served from the site root (or update paths if hosted in a subfolder).
4. Open the site on an Android Chrome device → browser menu → "Add to Home screen" / "Install app" to get the standalone installable experience.
5. Pair the Bluetooth thermal printer once from **Printer Setup** in the app drawer; the device is remembered for future prints where supported.
6. Periodically remind staff to use **Backup & Restore** in the drawer to download a JSON snapshot, since all data is local to that one device/browser.

## 7. Prompt to generate the remaining/expanded screens

Use this as a follow-up prompt (to Claude or another AI coding tool) to extend this codebase further:

> Using the existing Quick Bill PWA codebase (index.html, css/style.css, js/db.js, js/billing.js, js/printer.js, js/export.js, js/auth.js, js/app.js), extend it with:
> 1. A full **Customer Ledger** screen showing running balance, payment history, and an "Add Payment" action that writes to the `payments` store and updates `customers.balance`.
> 2. A **Return/Exchange** flow from Bill History that lets staff select specific line items and quantities to return, calling `Billing.returnBill()`, and prints a return receipt.
> 3. A **Purchase Entry** screen (vendor name, bill number, items received, cost price) that increases `items.stock` and logs a `stockLedger` entry with reason `purchase`.
> 4. Multi-user session handling with a lightweight admin-only **Settings** screen to edit shop name/address/GST/bill prefix (stored in `settings`) and manage `users`.
> 5. A **Low Stock Alerts** view filtering `items` where `stock <= reorderLevel`, with quick "Reorder" CSV export.
> 6. Barcode scanning via device camera using the `BarcodeDetector` API (with a graceful fallback to manual barcode entry) wired into the existing item picker in `app.js`.
>
> Keep all new code consistent with the existing dark/orange visual language in `css/style.css`, reuse `DB`, `Billing`, `ExportUtil`, and `Printer` modules rather than duplicating logic, and keep everything offline-first via IndexedDB.

---

**Note on scope:** this build focuses the Quick Bill screen pixel-close to your reference image, with fully working Inventory, Customers, Reports, Bill History, Printer pairing, and Backup/Restore behind the hamburger menu. Barcode camera scanning, a customer ledger UI, and a dedicated purchase-entry screen are stubbed out via the prompt above rather than fully built, to keep this first version lean and testable on your device.
