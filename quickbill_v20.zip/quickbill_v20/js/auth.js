/**
 * auth.js
 * Simple local PIN-based login for Admin / Staff roles.
 * Not for high-security use — suitable for a single-device shop till.
 */

const Auth = {
  currentUser: null,

  async login(username, pin) {
    const users = await DB.getByIndex(DB.STORES.users, 'username', username);
    const user = users[0];
    if (!user || user.pin !== pin) throw new Error('Invalid username or PIN');
    this.currentUser = user;
    sessionStorage.setItem('qb_session', JSON.stringify({ id: user.id, username: user.username, role: user.role, name: user.name }));
    return user;
  },

  restoreSession() {
    const raw = sessionStorage.getItem('qb_session');
    if (raw) this.currentUser = JSON.parse(raw);
    return this.currentUser;
  },

  logout() {
    this.currentUser = null;
    sessionStorage.removeItem('qb_session');
  },

  isAdmin() {
    return this.currentUser && this.currentUser.role === 'admin';
  },

  requireRole(role) {
    if (!this.currentUser) throw new Error('Not logged in');
    if (role === 'admin' && this.currentUser.role !== 'admin') throw new Error('Admin access required');
  }
};

window.Auth = Auth;
