/**
 * preview.js
 * Renders the Print Preview as a plain monospace "cash bill" receipt —
 * the exact same line content (buildReceiptLines, from printer.js) that
 * gets sent to the thermal printer, so what you see here is what prints.
 * Also handles sharing that receipt as an image via WhatsApp.
 */

const Preview = {
  BASE_SIZE: 15,
  LINE_H: 20,

  fontFor(l) {
    if (l.section === 'header') return `19px "Courier New", monospace`;      // 15 + 4
    if (l.section === 'grandtotal') return `bold 21px "Courier New", monospace`; // 15 + 6, bold
    if (l.bold) return `bold 17px "Courier New", monospace`;
    return `17px "Courier New", monospace`;                                   // 15 + 2 (body)
  },

  lineHeightFor(l) {
    if (l.section === 'header') return 24;
    if (l.section === 'grandtotal') return 28;
    return 22;
  },

  renderCanvas(bill, shop) {
    const lines = buildReceiptLines(bill, shop);

    const scale = 2;
    const padX = 20;
    const sepFont = `17px "Courier New", monospace`;

    // Measure every line at its real font so the canvas is always exactly
    // wide enough — hardcoding a per-character width breaks the moment
    // font sizes change (that's what caused text to run off the edge).
    const measureCanvas = document.createElement('canvas');
    const mctx = measureCanvas.getContext('2d');

    let maxTextWidth = 0;
    let height = 24;
    const lineHeights = lines.map((l) => {
      const h = this.lineHeightFor(l);
      height += h;
      mctx.font = l.sep ? sepFont : this.fontFor(l);
      const text = l.sep ? '-'.repeat(l.width) : l.text;
      const w = mctx.measureText(text).width;
      if (w > maxTextWidth) maxTextWidth = w;
      return h;
    });
    height += 20;

    const width = Math.ceil(maxTextWidth) + padX * 2;

    const canvas = document.createElement('canvas');
    canvas.width = width * scale;
    canvas.height = height * scale;
    const ctx = canvas.getContext('2d');
    ctx.scale(scale, scale);

    // Paper background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = '#1a1a1a';

    let y = 20;
    lines.forEach((l, i) => {
      const lineH = lineHeights[i];
      if (l.sep) {
        ctx.font = sepFont;
        ctx.textAlign = 'left';
        ctx.fillText('-'.repeat(l.width), padX, y);
        y += lineH;
        return;
      }

      ctx.font = this.fontFor(l);
      let x = padX;
      if (l.align === 'center') { ctx.textAlign = 'center'; x = width / 2; }
      else if (l.align === 'right') { ctx.textAlign = 'right'; x = width - padX; }
      else { ctx.textAlign = 'left'; x = padX; }

      ctx.fillText(l.text, x, y);
      y += lineH;
    });

    return canvas;
  },

  /** Opens the preview modal with Print / Share via WhatsApp / Close actions. */
  open(bill, shop) {
    const canvas = this.renderCanvas(bill, shop);
    const dataUrl = canvas.toDataURL('image/png');

    const modal = document.getElementById('modalPrintPreview');
    const img = document.getElementById('previewImg');
    img.src = dataUrl;
    modal.classList.add('open');

    const printBtn = document.getElementById('btnPreviewPrint');
    const waBtn = document.getElementById('btnPreviewWhatsApp');
    const closeBtn = document.getElementById('btnPreviewClose');

    const cleanup = () => {
      printBtn.onclick = null;
      waBtn.onclick = null;
      closeBtn.onclick = null;
    };

    printBtn.onclick = async () => {
      const result = await Printer.printBill(bill, shop);
      if (typeof toast === 'function') toast(`Printed via ${result.method}`);
      modal.classList.remove('open');
      cleanup();
    };

    waBtn.onclick = async () => {
      await this.shareToWhatsApp(canvas, bill);
    };

    closeBtn.onclick = () => {
      modal.classList.remove('open');
      cleanup();
    };
  },

  async shareToWhatsApp(canvas, bill) {
    canvas.toBlob(async (blob) => {
      const file = new File([blob], `${bill.billNo || 'bill'}.png`, { type: 'image/png' });

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({
            files: [file],
            title: bill.billNo || 'Bill',
            text: `Bill ${bill.billNo || ''} — Total Rs ${bill.grandTotal}`
          });
          return;
        } catch (e) {
          // user cancelled or share failed — fall through to download
        }
      }

      // Fallback: download the image and open WhatsApp so the user can attach it manually.
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${bill.billNo || 'bill'}.png`;
      a.click();
      URL.revokeObjectURL(url);
      if (typeof toast === 'function') {
        toast('Image saved — attach it in WhatsApp (direct share not supported on this browser)');
      }
      window.open('https://wa.me/', '_blank');
    }, 'image/png');
  }
};

window.Preview = Preview;
