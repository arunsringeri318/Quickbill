/**
 * sample-data.js
 * NOT included in index.html by default (the same data is now auto-seeded
 * into a fresh install by db.js -> seedDefaultsIfEmpty()). This file is kept
 * as a reference / for re-seeding manually from the console if needed:
 *   loadSampleData()
 */

const sampleItems = [
  { name: 'Basmati Rice 1kg', barcode: '8901030100001', category: 'Grocery', purchaseRate: 70, saleRate: 90, stock: 120, reorderLevel: 20 },
  { name: 'Toor Dal 1kg', barcode: '8901030100002', category: 'Grocery', purchaseRate: 110, saleRate: 135, stock: 60, reorderLevel: 15 },
  { name: 'Sunflower Oil 1L', barcode: '8901030100003', category: 'Grocery', purchaseRate: 140, saleRate: 165, stock: 40, reorderLevel: 10 },
  { name: 'Sugar 1kg', barcode: '8901030100004', category: 'Grocery', purchaseRate: 40, saleRate: 48, stock: 100, reorderLevel: 20 },
  { name: 'Wheat Flour 1kg', barcode: '8901030100005', category: 'Grocery', purchaseRate: 38, saleRate: 50, stock: 80, reorderLevel: 15 },
  { name: 'Parle-G Biscuit', barcode: '8901030100006', category: 'Snacks', purchaseRate: 8, saleRate: 10, stock: 300, reorderLevel: 50 },
  { name: 'Amul Milk 500ml', barcode: '8901030100007', category: 'Dairy', purchaseRate: 24, saleRate: 28, stock: 80, reorderLevel: 20 },
  { name: 'Tata Salt 1kg', barcode: '8901030100008', category: 'Grocery', purchaseRate: 18, saleRate: 22, stock: 90, reorderLevel: 20 }
];

const sampleCustomers = [
  { name: 'Ramesh Kumar', phone: '9880011223', address: 'Jayanagar, Bangalore', balance: 0 },
  { name: 'Priya Shah', phone: '9880033445', address: 'Indiranagar, Bangalore', balance: 250 },
  { name: 'Suresh Traders (Wholesale)', phone: '9880099887', address: 'KR Market, Bangalore', balance: 1800 },
  { name: 'Lakshmi Devi', phone: '9880055667', address: 'Basavanagudi, Bangalore', balance: 0 },
  { name: 'Manoj Enterprises', phone: '9880077889', address: 'Malleshwaram, Bangalore', balance: 500 }
];

async function loadSampleData() {
  await openDB();
  for (const item of sampleItems) await DB.add(DB.STORES.items, item);
  for (const c of sampleCustomers) await DB.add(DB.STORES.customers, c);
  console.log('Sample inventory and customers loaded.');
}

// Reference shapes for external integration / documentation purposes:

const BILL_MODEL_EXAMPLE = {
  id: 1,
  billNo: 'INV-0001',
  date: '2026-07-14T10:15:00.000Z',
  customerId: null,
  items: [
    { itemId: 1, name: 'Basmati Rice 1kg', barcode: '8901030100001', qty: 2, rate: 90, total: 180 }
  ],
  totalQty: 2,
  subTotal: 180,
  discount: 0,
  grandTotal: 180,
  paymentStatus: 'paid',
  paymentMode: 'cash',
  status: 'completed'
};
