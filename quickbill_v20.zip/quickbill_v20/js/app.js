/**
 * app.js
 * UI wiring: navigation, Quick Bill keypad/cart, inventory, customers,
 * reports, bill history, printer setup, backup/restore.
 */

let activeField = 'rate'; // 'qty' | 'rate'
let editingRowIndex = null; // row index being edited via SR pencil icon
let pendingRowForItem = null; // row index awaiting item pick, or null = new line
let editItemId = null;
let editCustomerId = null;
let currentReportTab = 'daily';
let currentHistoryBillId = null;
let currentItemWiseCategory = 'All';
let itemWisePickerMode = false;
let selectedPaymentMode = 'none';

const $ = (sel) => document.querySelector(sel);
const $all = (sel) => Array.from(document.querySelectorAll(sel));

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 1800);
}

function money(n) {
  return `₹${Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

function showScreen(name) {
  $all('.screen').forEach((s) => s.classList.remove('open'));
  $(`#screen-${name}`).classList.add('open');
  closeDrawer();
  if (name === 'inventory') renderInventory();
  if (name === 'customers') renderCustomers();
  if (name === 'reports') renderReport();
  if (name === 'billhistory') renderHistory();
  if (name === 'printer') renderPrinterStatus();
  if (name === 'itemwise') renderItemWise();
}

function openDrawer() {
  $('#drawer').classList.add('open');
  $('#drawerOverlay').classList.add('open');
}
function closeDrawer() {
  $('#drawer').classList.remove('open');
  $('#drawerOverlay').classList.remove('open');
}

function openModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

/* ===================== INIT ===================== */

window.addEventListener('DOMContentLoaded', async () => {
  await openDB();
  await DB.seedDefaultsIfEmpty();

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW failed', e));
  }

  const session = Auth.restoreSession();
  if (session) {
    showScreen('quickbill');
    $('#drawerUserName').textContent = session.name;
    $('#drawerUserRole').textContent = session.role;
  }

  bindGlobalEvents();
  setTabletLayout(localStorage.getItem('quickbill-tablet-layout') === 'true');
  applyTheme(localStorage.getItem('quickbill-theme') || 'orange');
  setActiveField('rate');
  renderCart();
  populateQuickBillCustomerSelect();
});

/* ===================== LOGIN ===================== */

$('#btnLogin').addEventListener('click', async () => {
  const username = $('#loginUser').value;
  const pin = $('#loginPin').value;
  try {
    const user = await Auth.login(username, pin);
    $('#drawerUserName').textContent = user.name;
    $('#drawerUserRole').textContent = user.role;
    showScreen('quickbill');
    toast(`Welcome, ${user.name}`);
  } catch (e) {
    toast(e.message);
  }
});

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen?.().catch(() => toast('Fullscreen not supported here'));
  } else {
    document.exitFullscreen?.();
  }
}

document.addEventListener('fullscreenchange', () => {
  const btn = $('#btnFullscreen');
  if (btn) btn.innerHTML = document.fullscreenElement ? '&#9975;' : '&#9974;';
});

/* ===================== NAV / DRAWER ===================== */

function bindGlobalEvents() {
  $('#btnMenu').addEventListener('click', openDrawer);
  $('#drawerOverlay').addEventListener('click', closeDrawer);
  $all('.drawer-item[data-nav]').forEach((el) => {
    el.addEventListener('click', () => showScreen(el.dataset.nav));
  });
  $('#btnLogout').addEventListener('click', () => {
    Auth.logout();
    closeDrawer();
    $all('.screen').forEach((s) => s.classList.remove('open'));
    $('#screen-login').classList.add('open');
  });
  $all('[data-back]').forEach((el) => {
    el.addEventListener('click', () => showScreen(el.dataset.back));
  });

  $('#btnFullscreen').addEventListener('click', toggleFullscreen);
  document.addEventListener('fullscreenchange', updateFullscreenIcon);

  $('#btnFullscreen').addEventListener('click', toggleFullscreen);

  $('#btnTopMenu').addEventListener('click', (e) => {
    e.stopPropagation();
    $('#topDropdown').classList.toggle('open');
  });
  document.addEventListener('click', () => $('#topDropdown').classList.remove('open'));

  $('#btnBillReport').addEventListener('click', () => {
    $('#topDropdown').classList.remove('open');
    showScreen('reports');
  });
  $('#btnItemWiseBill').addEventListener('click', () => {
    $('#topDropdown').classList.remove('open');
    showScreen('itemwise');
  });
  $('#btnLayoutToggle').addEventListener('click', () => setTabletLayout(!$('#app').classList.contains('tablet-layout')));
  $('#btnBillList').addEventListener('click', () => showScreen('billhistory'));

  bindQuickBill();
  bindInventory();
  bindCustomers();
  bindReports();
  bindHistory();
  bindPrinterSetup();
  bindTheme();
  bindBackup();
  bindItemWiseBill();
}

function setTabletLayout(enabled) {
  $('#app').classList.toggle('tablet-layout', enabled);
  localStorage.setItem('quickbill-tablet-layout', String(enabled));
  $('#btnLayoutToggle').innerHTML = `&#9646; Tablet layout: ${enabled ? 'On' : 'Off'}`;
}

function applyTheme(themeName) {
  $('#app').dataset.theme = themeName;
  localStorage.setItem('quickbill-theme', themeName);
  $all('.theme-swatch').forEach((el) => {
    el.classList.toggle('active', el.dataset.theme === themeName);
  });
}

function bindTheme() {
  $all('.theme-swatch').forEach((el) => {
    el.addEventListener('click', () => {
      applyTheme(el.dataset.theme);
      toast(`Theme set to ${el.querySelector('.theme-name').textContent}`);
    });
  });
}

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch((e) => toast('Fullscreen not available'));
  } else {
    document.exitFullscreen();
  }
}

function updateFullscreenIcon() {
  const btn = $('#btnFullscreen');
  btn.innerHTML = document.fullscreenElement ? '&#9975;' : '&#9974;';
}

/* ===================== QUICK BILL ===================== */

function bindQuickBill() {
  $('#quickBillCustomer').addEventListener('change', handleQuickBillCustomerChange);
  $('#qtyInput').addEventListener('click', () => { setActiveField('qty'); showNumericKeypad(); });
  $('#rateInput').addEventListener('click', () => { setActiveField('rate'); showNumericKeypad(); });
  $('#rateInput').addEventListener('input', (e) => checkPriceSuggestion(e.target.value));
  $('#itemNameInput').addEventListener('click', showQwertyKeyboard);
  $('#itemNameInput').addEventListener('focus', showQwertyKeyboard);

  bindNumericKeys();

  $('#btnEnter').addEventListener('click', commitLine);
  $('#btnSave').addEventListener('click', saveCurrentBill);
  $('#btnClear').addEventListener('click', handleClear);
  $('#btnPrint').addEventListener('click', printDraft);
}

/* ---- Keypad <-> QWERTY swap: Item Name entry uses an on-screen QWERTY
   keyboard instead of the device's native keyboard (itemNameInput is
   readonly), while Qty/Rate keep the existing numeric keypad untouched. ---- */

let numericKeysHTML = null;

function bindNumericKeys() {
  $all('#keypad .key').forEach((k) => {
    k.addEventListener('click', () => handleKey(k.dataset.k));
  });
}

function showNumericKeypad() {
  const keypad = $('#keypad');
  if (keypad.dataset.mode !== 'qwerty') return;
  keypad.innerHTML = numericKeysHTML;
  keypad.classList.remove('qwerty-mode');
  keypad.dataset.mode = 'numeric';
  bindNumericKeys();
}

const QWERTY_ROWS = ['1234567890', 'QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNM'];

function buildQwertyHTML() {
  let html = '';
  QWERTY_ROWS.forEach((row) => {
    html += '<div class="qwerty-row">';
    row.split('').forEach((ch) => {
      html += `<button type="button" class="qwerty-key" data-char="${ch.toLowerCase()}">${ch}</button>`;
    });
    html += '</div>';
  });
  html += `<div class="qwerty-row">
    <button type="button" class="qwerty-key qwerty-space" data-char=" ">Space</button>
    <button type="button" class="qwerty-key qwerty-backspace" data-char="back">&#9003;</button>
  </div>`;
  return html;
}

function bindQwertyKeys() {
  $all('#keypad .qwerty-key').forEach((k) => {
    k.addEventListener('click', () => {
      const input = $('#itemNameInput');
      if (k.dataset.char === 'back') {
        input.value = input.value.slice(0, -1);
      } else {
        input.value += k.dataset.char;
      }
      matchItemNameToInventory();
    });
  });
}

function showQwertyKeyboard() {
  const keypad = $('#keypad');
  if (keypad.dataset.mode === 'qwerty') return;
  if (numericKeysHTML === null) numericKeysHTML = keypad.innerHTML;
  keypad.innerHTML = buildQwertyHTML();
  keypad.classList.add('qwerty-mode');
  keypad.dataset.mode = 'qwerty';
  bindQwertyKeys();
}

/** If the typed item name exactly matches an existing inventory item
 * (case-insensitive), link it and offer the rate — no popup, just a
 * quiet lookup once you move on from the field. */
async function matchItemNameToInventory() {
  const name = $('#itemNameInput').value.trim();
  if (!name) { pendingItem = null; return; }

  const items = await DB.getAll(DB.STORES.items);
  const match = items.find((it) => it.name.trim().toLowerCase() === name.toLowerCase());

  if (match) {
    pendingItem = match;
    if (!$('#rateInput').value) $('#rateInput').value = match.saleRate || '';
  } else {
    pendingItem = { id: null, name };
  }
}

function setActiveField(f) {
  activeField = f;
  $('#qtyInput').classList.toggle('active', f === 'qty');
  $('#rateInput').classList.toggle('active', f === 'rate');
}

function handleKey(k) {
  const input = activeField === 'qty' ? $('#qtyInput') : $('#rateInput');
  let val = input.value || '';

  if (k === 'back') {
    val = val.slice(0, -1);
  } else if (k === '.') {
    if (!val.includes('.')) val += '.';
  } else {
    val += k;
  }
  input.value = val;

  if (activeField === 'rate') checkPriceSuggestion(val);
}

/* ---- Price-match suggestion: if the entered rate matches an inventory
   item's sale price, offer to auto-fill that item's details. ---- */

async function checkPriceSuggestion(rateStr) {
  const rate = parseFloat(rateStr);
  if (!rateStr || isNaN(rate)) return hidePriceSuggest();

  const items = await DB.getAll(DB.STORES.items);
  const matches = items.filter((it) => Number(it.saleRate) === rate);

  if (matches.length === 0) return hidePriceSuggest();
  renderPriceSuggest(matches, rate);
}

function renderPriceSuggest(matches, rate) {
  const wrap = $('#priceSuggest');
  wrap.innerHTML = `<span class="suggest-label">₹${rate}:</span>`;
  matches.forEach((item) => {
    const chip = document.createElement('span');
    chip.className = 'suggest-chip';
    chip.textContent = item.name;
    chip.addEventListener('click', () => {
      pendingItem = item;
      $('#rateInput').value = item.saleRate;
      $('#itemNameInput').value = item.name;
      setActiveField('qty');
      hidePriceSuggest();
      toast(`Linked to "${item.name}"`);
    });
    wrap.appendChild(chip);
  });
  wrap.classList.add('show');
}

function hidePriceSuggest() {
  const wrap = $('#priceSuggest');
  wrap.classList.remove('show');
  wrap.innerHTML = '';
}

function commitLine() {
  const qty = parseFloat($('#qtyInput').value);
  const rate = parseFloat($('#rateInput').value);
  const typedName = $('#itemNameInput').value.trim();

  if (!qty || qty <= 0) {
    toast('Enter quantity');
    setActiveField('qty');
    return;
  }
  if (isNaN(rate)) {
    toast('Enter rate');
    setActiveField('rate');
    return;
  }

  let itemForLine = pendingItem;
  if (typedName && (!pendingItem || pendingItem.name !== typedName)) {
    itemForLine = { id: null, name: typedName };
  }

  if (editingRowIndex !== null) {
    Billing.updateLine(editingRowIndex, qty, rate);
    const line = Billing.cart[editingRowIndex];
    if (line && itemForLine) {
      line.itemId = itemForLine.id || null;
      line.name = itemForLine.name || line.name;
    }
    editingRowIndex = null;
  } else {
    Billing.addLine(itemForLine, qty, rate);
    pendingItem = null;
  }

  $('#qtyInput').value = '';
  $('#rateInput').value = '';
  $('#itemNameInput').value = '';
  setActiveField('rate');
  showNumericKeypad();
  hidePriceSuggest();
  renderCart();
}

let pendingItem = null;

function handleClear() {
  if ($('#qtyInput').value || $('#rateInput').value || $('#itemNameInput').value) {
    $('#qtyInput').value = '';
    $('#rateInput').value = '';
    $('#itemNameInput').value = '';
    pendingItem = null;
    editingRowIndex = null;
    setActiveField('rate');
    showNumericKeypad();
    hidePriceSuggest();
    return;
  }
  if (Billing.cart.length === 0) return;
  if (confirm('Clear the entire bill?')) {
    Billing.clearCart();
    renderCart();
  }
}

function renderCart() {
  const wrap = $('#billRows');
  wrap.innerHTML = '';

  if (Billing.cart.length === 0) {
    wrap.innerHTML = '<div class="empty-hint">No items yet. Type an item name (optional), enter Qty &amp; Rate, then tap Enter.</div>';
  } else {
    Billing.cart.forEach((line, i) => {
      const row = document.createElement('div');
      row.className = 'bill-row';
      row.innerHTML = `
        <span class="sr">${i + 1}<span class="edit-icon" data-edit="${i}">&#9998;</span></span>
        <span class="details" data-edit="${i}">${line.name && line.name !== 'Item' ? line.name : '<span class="add-icon">&#8853;</span>'}</span>
        <span class="qty">${line.qty}</span>
        <span class="rate">${line.rate}</span>
        <span class="total">${line.total}</span>
      `;
      wrap.appendChild(row);
    });

    $all('[data-edit]').forEach((el) => {
      el.addEventListener('click', () => {
        const i = Number(el.dataset.edit);
        const line = Billing.cart[i];
        editingRowIndex = i;
        pendingItem = line.itemId ? { id: line.itemId, name: line.name, barcode: line.barcode } : null;
        $('#itemNameInput').value = line.name && line.name !== 'Item' ? line.name : '';
        $('#qtyInput').value = line.qty;
        $('#rateInput').value = line.rate;
        setActiveField('qty');
        showNumericKeypad();
      });
    });
  }

  const { totalQty, totalAmount } = Billing.totals();
  $('#sumQty').textContent = totalQty;
  $('#sumAmount').textContent = money(totalAmount);
  if ($('#itemWiseRows')) renderItemWiseCart();
}

async function saveCurrentBill() {
  // commit any pending keypad entry first
  if ($('#qtyInput').value && $('#rateInput').value) commitLine();

  if (Billing.cart.length === 0) {
    toast('Add at least one item');
    return;
  }
  try {
    const customerId = $('#quickBillCustomer').value ? Number($('#quickBillCustomer').value) : null;
    const bill = await Billing.saveBill({ customerId, paymentStatus: 'paid', paymentMode: 'cash' });
    const savedMsg = bill.newInventoryItems && bill.newInventoryItems.length
      ? `Bill ${bill.billNo} saved · Added "${bill.newInventoryItems.join('", "')}" to inventory`
      : `Bill ${bill.billNo} saved`;
    toast(savedMsg);
    renderCart();
    $('#quickBillCustomer').value = '';
    const shop = await DB.get(DB.STORES.settings, 'shop');
    Preview.open(bill, shop);
  } catch (e) {
    toast(e.message);
  }
}

async function populateQuickBillCustomerSelect() {
  const select = $('#quickBillCustomer');
  if (!select) return;
  const prevValue = select.value;
  const customers = await DB.getAll(DB.STORES.customers);
  customers.sort((a, b) => a.name.localeCompare(b.name));

  select.innerHTML = '<option value="">No Customer</option>' +
    '<option value="__add_new__">+ Add New Customer</option>' +
    customers.map((c) => `<option value="${c.id}">${c.name}${c.phone ? ' · ' + c.phone : ''}</option>`).join('');

  if (prevValue && customers.some((c) => String(c.id) === prevValue)) {
    select.value = prevValue;
  }
}

let quickBillCustomerPendingSelect = false;

function handleQuickBillCustomerChange() {
  const select = $('#quickBillCustomer');
  if (select.value === '__add_new__') {
    quickBillCustomerPendingSelect = true;
    select.value = '';
    openCustomerModal(null);
  }
}

async function printDraft() {
  if (Billing.cart.length === 0) {
    toast('Nothing to print yet');
    return;
  }
  const { totalQty, totalAmount } = Billing.totals();
  const draft = {
    billNo: 'DRAFT',
    date: new Date().toISOString(),
    items: Billing.cart,
    totalQty,
    grandTotal: totalAmount
  };
  const shop = await DB.get(DB.STORES.settings, 'shop');
  const result = await Printer.printBill(draft, shop);
  toast(`Printed via ${result.method}`);
}

/* ===================== ITEM WISE BILL ===================== */

function bindItemWiseBill() {
  $('#btnItemWiseMenu').addEventListener('click', openDrawer);
  $('#btnItemWiseQuick').addEventListener('click', () => showScreen('quickbill'));
  $('#btnItemWiseReport').addEventListener('click', () => showScreen('reports'));
  $('#btnItemWiseClear').addEventListener('click', () => {
    if (Billing.cart.length && confirm('Clear the entire bill?')) { Billing.clearCart(); renderCart(); }
  });
  $('#btnItemWisePicker').addEventListener('click', () => {
    itemWisePickerMode = true;
    openItemPicker('');
  });
  $('#btnItemWisePrint').addEventListener('click', printDraft);
  $('#btnItemWiseSave').addEventListener('click', openSaveBill);
  $('#btnSaveBillAddCustomer').addEventListener('click', () => openCustomerModal(null));
  $('#btnCancelSaveBill').addEventListener('click', () => showScreen('itemwise'));
  $('#btnConfirmSaveBill').addEventListener('click', () => completeItemWiseBill(false));
  $('#btnSaveAndPrint').addEventListener('click', () => completeItemWiseBill(true));
  $all('.payment-tab').forEach((button) => button.addEventListener('click', () => {
    selectedPaymentMode = button.dataset.payment;
    $all('.payment-tab').forEach((tab) => tab.classList.toggle('active', tab === button));
  }));
}

async function renderItemWise() {
  await renderItemWiseProducts();
  renderItemWiseCart();
}

async function renderItemWiseProducts() {
  const items = await DB.getAll(DB.STORES.items);
  const categories = ['All', ...Array.from(new Set(items.map((item) => item.category).filter(Boolean)))];
  if (!categories.includes(currentItemWiseCategory)) currentItemWiseCategory = 'All';
  const categoryWrap = $('#itemWiseCategories');
  categoryWrap.innerHTML = '';
  categories.forEach((category) => {
    const button = document.createElement('button');
    button.textContent = category;
    button.classList.toggle('active', category === currentItemWiseCategory);
    button.addEventListener('click', () => { currentItemWiseCategory = category; renderItemWiseProducts(); });
    categoryWrap.appendChild(button);
  });
  const productWrap = $('#itemWiseProducts');
  productWrap.innerHTML = '';
  items.filter((item) => currentItemWiseCategory === 'All' || item.category === currentItemWiseCategory).forEach((item) => {
    const button = document.createElement('button');
    button.className = 'item-product';
    button.innerHTML = `${item.name}<span class="price">${money(item.saleRate)}</span>`;
    button.addEventListener('click', () => addItemWiseProduct(item));
    productWrap.appendChild(button);
  });
}

function addItemWiseProduct(item) {
  const existingIndex = Billing.cart.findIndex((line) => line.itemId === item.id);
  if (existingIndex >= 0) {
    const line = Billing.cart[existingIndex];
    Billing.updateLine(existingIndex, Number(line.qty) + 1, line.rate);
  } else {
    Billing.addLine(item, 1, Number(item.saleRate) || 0);
  }
  renderCart();
}

function renderItemWiseCart() {
  const wrap = $('#itemWiseRows');
  if (!wrap) return;
  wrap.innerHTML = '';
  Billing.cart.forEach((line, index) => {
    const row = document.createElement('div');
    row.className = 'itemwise-row';
    row.innerHTML = `<span class="itemwise-name">${index + 1}. ${line.name}</span><span>${line.qty}</span><span>${money(line.rate)}</span><span>${money(line.total)}</span>`;
    row.title = 'Tap to remove this item';
    row.addEventListener('click', () => { Billing.removeLine(index); renderCart(); });
    wrap.appendChild(row);
  });
  if (Billing.cart.length === 0) wrap.innerHTML = '<div class="empty-hint">Choose products below to add them to the bill.</div>';
  const totals = Billing.totals();
  $('#itemWiseQty').textContent = totals.totalQty;
  $('#itemWiseAmount').textContent = money(totals.totalAmount);
}

async function openSaveBill() {
  if (Billing.cart.length === 0) return toast('Add at least one item');
  const customers = await DB.getAll(DB.STORES.customers);
  $('#saveBillCustomer').innerHTML = '<option value="">Select Customer...</option>' + customers.map((c) => `<option value="${c.id}">${c.name}${c.phone ? ` · ${c.phone}` : ''}</option>`).join('');
  const totals = Billing.totals();
  $('#saveBillTotal').textContent = money(totals.totalAmount);
  $('#saveBillSubTotal').textContent = money(totals.totalAmount);
  $('#saveBillGrandTotal').textContent = money(totals.totalAmount);
  $('#saveBillDate').textContent = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
  $('#saveBillNote').value = '';
  selectedPaymentMode = 'none';
  $all('.payment-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.payment === 'none'));
  showScreen('savebill');
}

async function completeItemWiseBill(withPrint) {
  try {
    const customerId = Number($('#saveBillCustomer').value) || null;
    const paymentMode = selectedPaymentMode === 'none' ? 'cash' : selectedPaymentMode;
    const paymentStatus = selectedPaymentMode === 'credit' ? 'unpaid' : 'paid';
    const bill = await Billing.saveBill({ customerId, paymentMode, paymentStatus });
    const note = $('#saveBillNote').value.trim();
    if (note) await Billing.editBill(bill.id, { note });
    const savedMsg = bill.newInventoryItems && bill.newInventoryItems.length
      ? `Bill ${bill.billNo} saved · Added "${bill.newInventoryItems.join('", "')}" to inventory`
      : `Bill ${bill.billNo} saved`;
    toast(savedMsg);
    renderCart();
    await renderItemWiseProducts();
    showScreen('itemwise');
    if (withPrint) {
      const shop = await DB.get(DB.STORES.settings, 'shop');
      Preview.open(bill, shop);
    }
  } catch (error) {
    toast(error.message);
  }
}

/* ===================== ITEM PICKER ===================== */

async function openItemPicker(query) {
  openModal('#modalPicker');
  $('#pickerSearch').value = query || '';
  await renderPickerList(query || '');
  $('#pickerSearch').oninput = (e) => renderPickerList(e.target.value);
}

async function renderPickerList(query) {
  const items = await DB.getAll(DB.STORES.items);
  const q = query.trim().toLowerCase();
  const filtered = q
    ? items.filter((it) => it.name.toLowerCase().includes(q) || (it.barcode || '').includes(q))
    : items;

  const list = $('#pickerList');
  list.innerHTML = '';

  if (filtered.length === 0) {
    list.innerHTML = `<div class="empty-hint">No matching item.
      <div class="btn orange" id="btnUseAsManual" style="margin-top:10px;">Use "${query}" as manual entry</div></div>`;
    const manualBtn = $('#btnUseAsManual');
    if (manualBtn) {
      manualBtn.addEventListener('click', () => selectItemForRow({ id: null, name: query || 'Item', saleRate: 0 }));
    }
    return;
  }

  filtered.forEach((it) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="row1"><span>${it.name}</span><span>${money(it.saleRate)}</span></div>
      <div class="row2"><span>${it.barcode || 'No barcode'}</span><span class="${Number(it.stock) <= Number(it.reorderLevel || 0) ? 'low-stock' : ''}">Stock: ${it.stock ?? 0}</span></div>
    `;
    card.addEventListener('click', () => selectItemForRow(it));
    list.appendChild(card);
  });
}

function selectItemForRow(item) {
  closeModal('#modalPicker');
  if (itemWisePickerMode) {
    itemWisePickerMode = false;
    addItemWiseProduct(item);
    return;
  }
  if (pendingRowForItem !== null) {
    const line = Billing.cart[pendingRowForItem];
    line.itemId = item.id;
    line.name = item.name;
    line.barcode = item.barcode || '';
    if (!line.rate) line.rate = Number(item.saleRate) || 0;
    line.total = +(line.qty * line.rate).toFixed(2);
    pendingRowForItem = null;
    renderCart();
  } else {
    pendingItem = item;
    $('#rateInput').value = item.saleRate || '';
    setActiveField('qty');
  }
}

/* ===================== INVENTORY ===================== */

function bindInventory() {
  $('#btnAddItem').addEventListener('click', () => openItemModal(null));
  $('#invSearch').addEventListener('input', (e) => renderInventory(e.target.value));
  $('#btnSaveItem').addEventListener('click', saveItem);
  $('#btnDeleteItem').addEventListener('click', deleteItem);

  $('#btnInvExportCSV').addEventListener('click', exportInventoryCSV);

  $('#btnInvImport').addEventListener('click', () => $('#invImportFile').click());
  $('#invImportFile').addEventListener('change', (e) => importInventory(e.target.files[0]));
}

async function renderInventory(query) {
  const items = await DB.getAll(DB.STORES.items);
  const q = (query || '').trim().toLowerCase();
  const filtered = q ? items.filter((it) => it.name.toLowerCase().includes(q) || (it.barcode || '').includes(q)) : items;

  const list = $('#invList');
  list.innerHTML = '';
  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty-hint">No items in inventory yet. Tap + to add one.</div>';
    return;
  }
  filtered.forEach((it) => {
    const card = document.createElement('div');
    card.className = 'card';
    const low = Number(it.stock) <= Number(it.reorderLevel || 0);
    card.innerHTML = `
      <div class="row1"><span>${it.name}</span><span>${money(it.saleRate)}</span></div>
      <div class="row2"><span>${it.category || 'Uncategorized'}</span><span class="${low ? 'low-stock' : ''}">Stock: ${it.stock ?? 0}</span></div>
    `;
    card.addEventListener('click', () => openItemModal(it));
    list.appendChild(card);
  });
}

function openItemModal(item) {
  editItemId = item ? item.id : null;
  $('#itemModalTitle').textContent = item ? 'Edit Item' : 'Add Item';
  $('#itemName').value = item?.name || '';
  $('#itemBarcode').value = item?.barcode || '';
  $('#itemCategory').value = item?.category || '';
  $('#itemPurchaseRate').value = item?.purchaseRate ?? '';
  $('#itemSaleRate').value = item?.saleRate ?? '';
  $('#itemStock').value = item?.stock ?? '';
  $('#itemReorder').value = item?.reorderLevel ?? '';
  $('#btnDeleteItem').style.display = item ? 'block' : 'none';
  openModal('#modalItem');
}

async function saveItem() {
  const name = $('#itemName').value.trim();
  if (!name) return toast('Item name required');

  const item = {
    name,
    barcode: $('#itemBarcode').value.trim(),
    category: $('#itemCategory').value.trim(),
    purchaseRate: parseFloat($('#itemPurchaseRate').value) || 0,
    saleRate: parseFloat($('#itemSaleRate').value) || 0,
    stock: parseFloat($('#itemStock').value) || 0,
    reorderLevel: parseFloat($('#itemReorder').value) || 0
  };
  if (editItemId) item.id = editItemId;

  await DB.put(DB.STORES.items, item);
  closeModal('#modalItem');
  toast('Item saved');
  renderInventory();
}

async function deleteItem() {
  if (!editItemId) return;
  if (!confirm('Delete this item?')) return;
  await DB.delete(DB.STORES.items, editItemId);
  closeModal('#modalItem');
  renderInventory();
}

const INVENTORY_HEADERS = ['name', 'barcode', 'category', 'purchaseRate', 'saleRate', 'stock', 'reorderLevel'];

async function exportInventoryCSV() {
  const items = await DB.getAll(DB.STORES.items);
  ExportUtil.downloadCSV('inventory', items, INVENTORY_HEADERS);
  toast('Inventory exported (CSV)');
}

/** Parses a simple CSV (no embedded-comma quoting beyond basic cases). */
function parseCSV(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return [];
  const headers = lines[0].split(',').map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cells = line.split(',').map((c) => c.trim());
    const row = {};
    headers.forEach((h, i) => { row[h] = cells[i]; });
    return row;
  });
}

async function importInventory(file) {
  if (!file) return;
  try {
    const text = await file.text();
    const rows = parseCSV(text);

    if (!Array.isArray(rows) || rows.length === 0) {
      toast('No rows found in file');
      return;
    }

    let added = 0, updated = 0;
    const existing = await DB.getAll(DB.STORES.items);

    for (const row of rows) {
      if (!row.name) continue;
      const item = {
        name: String(row.name).trim(),
        barcode: String(row.barcode || '').trim(),
        category: String(row.category || '').trim(),
        purchaseRate: parseFloat(row.purchaseRate) || 0,
        saleRate: parseFloat(row.saleRate) || 0,
        stock: parseFloat(row.stock) || 0,
        reorderLevel: parseFloat(row.reorderLevel) || 0
      };

      // Match existing item by barcode (if present) or exact name, to upsert rather than duplicate.
      const match = existing.find((it) =>
        (item.barcode && it.barcode === item.barcode) ||
        (!item.barcode && it.name.toLowerCase() === item.name.toLowerCase())
      );

      if (match) {
        item.id = match.id;
        await DB.put(DB.STORES.items, item);
        updated++;
      } else {
        const newId = await DB.add(DB.STORES.items, item);
        existing.push({ ...item, id: newId });
        added++;
      }
    }

    toast(`Import done: ${added} added, ${updated} updated`);
    renderInventory();
  } catch (e) {
    toast(`Import failed: ${e.message}`);
  } finally {
    $('#invImportFile').value = '';
  }
}

/* ===================== CUSTOMERS ===================== */

function bindCustomers() {
  $('#btnAddCustomer').addEventListener('click', () => openCustomerModal(null));
  $('#custSearch').addEventListener('input', (e) => renderCustomers(e.target.value));
  $('#btnSaveCustomer').addEventListener('click', saveCustomer);
  $('#btnDeleteCustomer').addEventListener('click', deleteCustomer);
  $('#btnCustExport').addEventListener('click', exportCustomers);
}

async function renderCustomers(query) {
  const customers = await DB.getAll(DB.STORES.customers);
  const q = (query || '').trim().toLowerCase();
  const filtered = q ? customers.filter((c) => c.name.toLowerCase().includes(q) || (c.phone || '').includes(q)) : customers;

  const list = $('#custList');
  list.innerHTML = '';
  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty-hint">No customers yet. Tap + to add one.</div>';
    return;
  }
  filtered.forEach((c) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="row1"><span>${c.name}</span><span>${money(c.balance || 0)}</span></div>
      <div class="row2"><span>${c.phone || ''}</span><span>${c.address || ''}</span></div>
    `;
    card.addEventListener('click', () => openCustomerModal(c));
    list.appendChild(card);
  });
}

function openCustomerModal(c) {
  editCustomerId = c ? c.id : null;
  $('#custModalTitle').textContent = c ? 'Edit Customer' : 'Add Customer';
  $('#custName').value = c?.name || '';
  $('#custPhone').value = c?.phone || '';
  $('#custAddress').value = c?.address || '';
  $('#btnDeleteCustomer').style.display = c ? 'block' : 'none';
  openModal('#modalCustomer');
}

async function saveCustomer() {
  const name = $('#custName').value.trim();
  if (!name) return toast('Customer name required');
  const customer = {
    name,
    phone: $('#custPhone').value.trim(),
    address: $('#custAddress').value.trim(),
    balance: 0
  };
  if (editCustomerId) {
    const existing = await DB.get(DB.STORES.customers, editCustomerId);
    customer.balance = existing?.balance || 0;
    customer.id = editCustomerId;
  }
  const newId = await DB.put(DB.STORES.customers, customer);
  closeModal('#modalCustomer');
  toast('Customer saved');
  renderCustomers();
  await populateQuickBillCustomerSelect();

  if (quickBillCustomerPendingSelect) {
    quickBillCustomerPendingSelect = false;
    const select = $('#quickBillCustomer');
    if (select) select.value = String(editCustomerId || newId);
  }
}

async function deleteCustomer() {
  if (!editCustomerId) return;
  if (!confirm('Delete this customer?')) return;
  await DB.delete(DB.STORES.customers, editCustomerId);
  closeModal('#modalCustomer');
  renderCustomers();
  populateQuickBillCustomerSelect();
}

async function exportCustomers() {
  const customers = await DB.getAll(DB.STORES.customers);
  const headers = ['name', 'phone', 'address', 'balance'];
  ExportUtil.downloadCSV('customers', customers, headers);
  toast('Customers exported');
}

/* ===================== REPORTS ===================== */

function bindReports() {
  $all('.tab').forEach((t) => t.addEventListener('click', () => setReportTab(t.dataset.tab)));
}

function setReportTab(tab) {
  currentReportTab = tab;
  $all('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
  renderReport();
}

async function renderReport() {
  const body = $('#reportBody');
  const today = new Date();
  const dateStr = today.toISOString().slice(0, 10);

  if (currentReportTab === 'daily') {
    const r = await Billing.dailySales(dateStr);
    body.innerHTML = `
      <div class="stat-grid">
        <div class="stat"><div class="label">Bills Today</div><div class="value">${r.billCount}</div></div>
        <div class="stat"><div class="label">Qty Sold</div><div class="value">${r.totalQty}</div></div>
        <div class="stat"><div class="label">Sales Amount</div><div class="value">${money(r.totalAmount)}</div></div>
      </div>
      <button class="btn orange" id="btnExportReport">Export Daily Report (CSV)</button>
    `;
    $('#btnExportReport').addEventListener('click', () => {
      ExportUtil.downloadCSV('daily-report', [r], ['billCount', 'totalQty', 'totalAmount']);
    });
  }

  if (currentReportTab === 'monthly') {
    const r = await Billing.monthlySales(today.getFullYear(), today.getMonth() + 1);
    body.innerHTML = `
      <div class="stat-grid">
        <div class="stat"><div class="label">Bills This Month</div><div class="value">${r.billCount}</div></div>
        <div class="stat"><div class="label">Qty Sold</div><div class="value">${r.totalQty}</div></div>
        <div class="stat"><div class="label">Sales Amount</div><div class="value">${money(r.totalAmount)}</div></div>
      </div>
      <button class="btn orange" id="btnExportReport">Export Monthly Report (CSV)</button>
    `;
    $('#btnExportReport').addEventListener('click', () => {
      ExportUtil.downloadCSV('monthly-report', [r], ['billCount', 'totalQty', 'totalAmount']);
    });
  }

  if (currentReportTab === 'itemwise') {
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString();
    const monthEnd = new Date().toISOString();
    const rows = await Billing.itemWiseSales(monthStart, monthEnd);
    rows.sort((a, b) => b.amount - a.amount);
    body.innerHTML = `
      ${rows.map((r) => `
        <div class="card">
          <div class="row1"><span>${r.name}</span><span>${money(r.amount)}</span></div>
          <div class="row2"><span>Qty sold</span><span>${r.qty}</span></div>
        </div>
      `).join('') || '<div class="empty-hint">No sales this month yet.</div>'}
      <button class="btn orange" id="btnExportReport">Export Item Wise (CSV)</button>
    `;
    $('#btnExportReport').addEventListener('click', () => {
      ExportUtil.downloadCSV('item-wise-report', rows, ['name', 'qty', 'amount']);
    });
  }

  if (currentReportTab === 'profit') {
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString();
    const monthEnd = new Date().toISOString();
    const r = await Billing.profitReport(monthStart, monthEnd);
    body.innerHTML = `
      <div class="stat-grid">
        <div class="stat"><div class="label">Revenue</div><div class="value">${money(r.revenue)}</div></div>
        <div class="stat"><div class="label">Cost</div><div class="value">${money(r.cost)}</div></div>
        <div class="stat"><div class="label">Profit</div><div class="value">${money(r.profit)}</div></div>
      </div>
    `;
  }
}

/* ===================== BILL HISTORY ===================== */

function bindHistory() {
  $('#histSearch').addEventListener('input', (e) => renderHistory(e.target.value));
  $('#btnHistExport').addEventListener('click', exportHistory);
  $('#btnReprint').addEventListener('click', reprintFromHistory);
  $('#btnExportImage').addEventListener('click', exportBillImage);
  $('#btnVoidBill').addEventListener('click', voidFromHistory);
  $('#btnDeleteBillHist').addEventListener('click', deleteFromHistory);
}

async function renderHistory(query) {
  const bills = (await DB.getAll(DB.STORES.bills)).sort((a, b) => b.date.localeCompare(a.date));
  const q = (query || '').trim().toLowerCase();
  const filtered = q ? bills.filter((b) => b.billNo.toLowerCase().includes(q)) : bills;

  const list = $('#histList');
  list.innerHTML = '';
  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty-hint">No bills yet.</div>';
    return;
  }
  filtered.forEach((b) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="row1"><span>${b.billNo}</span><span>${money(b.grandTotal)}</span></div>
      <div class="row2"><span>${new Date(b.date).toLocaleString()}</span><span>${b.status}${b.status === 'completed' ? ' / ' + b.paymentStatus : ''}</span></div>
    `;
    card.addEventListener('click', () => openBillDetail(b));
    list.appendChild(card);
  });
}

function openBillDetail(bill) {
  currentHistoryBillId = bill.id;
  $('#billDetailTitle').textContent = `${bill.billNo} · ${bill.status}`;
  $('#billDetailBody').innerHTML = `
    ${bill.items.map((l) => `
      <div class="card"><div class="row1"><span>${l.name}</span><span>${money(l.total)}</span></div>
      <div class="row2"><span>Qty ${l.qty}</span><span>Rate ${money(l.rate)}</span></div></div>
    `).join('')}
    <div class="stat-grid" style="margin-top:8px;">
      <div class="stat"><div class="label">Total Qty</div><div class="value">${bill.totalQty}</div></div>
      <div class="stat"><div class="label">Grand Total</div><div class="value grand">${money(bill.grandTotal)}</div></div>
    </div>
  `;
  $('#btnVoidBill').style.display = bill.status === 'void' ? 'none' : 'block';
  openModal('#modalBillDetail');
}

async function exportBillImage() {
  const bill = await DB.get(DB.STORES.bills, currentHistoryBillId);
  const shop = await DB.get(DB.STORES.settings, 'shop');
  if (!bill) return;

  const canvas = Preview.renderCanvas(bill, shop);
  canvas.toBlob((blob) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${bill.billNo}.png`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Bill image saved');
  }, 'image/png');
}

async function reprintFromHistory() {
  const bill = await DB.get(DB.STORES.bills, currentHistoryBillId);
  const shop = await DB.get(DB.STORES.settings, 'shop');
  closeModal('#modalBillDetail');
  Preview.open(bill, shop);
}

async function voidFromHistory() {
  if (!confirm('Void this bill and restock items?')) return;
  await Billing.voidBill(currentHistoryBillId);
  closeModal('#modalBillDetail');
  renderHistory();
  toast('Bill voided');
}

async function deleteFromHistory() {
  if (!confirm('Permanently delete this bill?')) return;
  await Billing.deleteBill(currentHistoryBillId);
  closeModal('#modalBillDetail');
  renderHistory();
  toast('Bill deleted');
}

async function exportHistory() {
  const bills = await DB.getAll(DB.STORES.bills);
  const headers = ['billNo', 'date', 'totalQty', 'grandTotal', 'paymentStatus', 'status'];
  ExportUtil.downloadCSV('bill-history', bills, headers);
  toast('Bill history exported');
}

/* ===================== PRINTER SETUP ===================== */

function bindPrinterSetup() {
  $('#btnConnectPrinter').addEventListener('click', async () => {
    try {
      const device = await Printer.connect();
      toast(`Connected: ${device.name || 'printer'}`);
      renderPrinterStatus();
    } catch (e) {
      toast(e.message);
    }
  });

  $('#paperWidthSlider').addEventListener('input', (event) => {
    $('#paperWidthValue').textContent = `${event.target.value} mm`;
  });
  $('#paperWidthSlider').addEventListener('change', (event) => setPaperWidthMm(event.target.value));

  $all('[data-align-group]').forEach((el) => {
    el.addEventListener('click', () => {
      const group = el.dataset.alignGroup;
      $all(`[data-align-group="${group}"]`).forEach((t) => t.classList.toggle('active', t === el));
    });
  });
  $all('[data-size-group]').forEach((el) => {
    el.addEventListener('click', () => {
      const group = el.dataset.sizeGroup;
      $all(`[data-size-group="${group}"]`).forEach((t) => t.classList.toggle('active', t === el));
    });
  });

  $('#btnSaveTemplate').addEventListener('click', saveReceiptTemplate);
  $('#btnTestPrint').addEventListener('click', sendTestPrint);
  $('#btnTemplatePreview').addEventListener('click', showTemplatePreview);
}

function getActiveValue(selector, attr) {
  const active = document.querySelector(`${selector}.active`);
  return active ? active.dataset[attr] : null;
}

async function saveReceiptTemplate() {
  const settings = await DB.get(DB.STORES.settings, 'shop');
  settings.customHeaderText = limitReceiptLines($('#tplHeaderText').value);
  settings.customFooterText = limitReceiptLines($('#tplFooterText').value);
  settings.footerAlign = getActiveValue('[data-align-group="footer"]', 'align') || 'center';
  await DB.put(DB.STORES.settings, settings);
  toast('Receipt template saved');
}

function limitReceiptLines(value) {
  return String(value || '').replace(/\r/g, '').split('\n').slice(0, 4).join('\n').trim();
}

async function sendTestPrint() {
  const settings = await DB.get(DB.STORES.settings, 'shop');
  const testBill = sampleTestBill();
  const result = await Printer.printBill(testBill, settings);
  toast(`Test print sent via ${result.method}`);
}

async function showTemplatePreview() {
  const settings = await DB.get(DB.STORES.settings, 'shop');
  Preview.open(sampleTestBill(), settings);
}

function sampleTestBill() {
  return {
    billNo: 'TEST-0001',
    date: new Date().toISOString(),
    items: [
      { name: 'Sugar', qty: 5, rate: 48, total: 240 },
      { name: 'Rice', qty: 6, rate: 60, total: 360 },
      { name: 'Dall', qty: 2, rate: 70, total: 140 },
      { name: 'Flour', qty: 3, rate: 50, total: 150 },
      { name: 'Oil', qty: 1, rate: 130, total: 130 }
    ],
    totalQty: 17,
    grandTotal: 1020
  };
}

function setActiveInGroup(selector, attr, value) {
  $all(selector).forEach((el) => el.classList.toggle('active', el.dataset[attr] === value));
}

async function setPaperWidthMm(width) {
  const settings = await DB.get(DB.STORES.settings, 'shop');
  settings.paperWidthMm = Math.max(50, Math.min(100, Math.round(Number(width) || 76)));
  delete settings.paperWidth;
  await DB.put(DB.STORES.settings, settings);
  renderPrinterStatus();
  toast(`Printer set to ${settings.paperWidthMm} mm`);
}

async function renderPrinterStatus() {
  const settings = await DB.get(DB.STORES.settings, 'shop');
  $('#printerStatus').textContent = settings?.printerDeviceName
    ? `${settings.printerDeviceName} (last paired)`
    : 'Not connected';

  const width = typeof getPaperWidthMm === 'function' ? getPaperWidthMm(settings) : 76;
  $('#paperWidthSlider').value = width;
  $('#paperWidthValue').textContent = `${width} mm`;

  $('#tplHeaderText').value = settings?.customHeaderText || '';
  $('#tplFooterText').value = settings?.customFooterText || '';
  setActiveInGroup('[data-align-group="footer"]', 'align', settings?.footerAlign || 'center');
}

/* ===================== BACKUP & RESTORE ===================== */

function bindBackup() {
  $('#btnBackup').addEventListener('click', async () => {
    const dump = await DB.exportAll();
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `quickbill-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Backup downloaded');
  });

  $('#btnRestore').addEventListener('click', async () => {
    const file = $('#restoreFile').files[0];
    if (!file) return toast('Choose a backup file first');
    if (!confirm('This will overwrite all current data. Continue?')) return;
    const text = await file.text();
    const dump = JSON.parse(text);
    await DB.importAll(dump);
    toast('Restore complete');
  });
}

/* ===================== MODAL CLOSE ON OVERLAY CLICK ===================== */

$all('.modal-overlay').forEach((overlay) => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      overlay.classList.remove('open');
      if (overlay.id === 'modalCustomer') quickBillCustomerPendingSelect = false;
    }
  });
});
