/**
 * export.js
 * CSV / Excel(CSV-compatible) / PDF export helpers.
 * No external libraries required: CSV is native, PDF uses the browser's
 * print-to-PDF via a formatted print window (works fully offline).
 */

const ExportUtil = {
  toCSV(rows, headers) {
    const escape = (v) => {
      const s = String(v ?? '');
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [headers.map(escape).join(',')];
    for (const row of rows) {
      lines.push(headers.map((h) => escape(row[h])).join(','));
    }
    return lines.join('\n');
  },

  downloadCSV(filename, rows, headers) {
    const csv = this.toCSV(rows, headers);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    this._download(blob, filename.endsWith('.csv') ? filename : `${filename}.csv`);
  },

  /** Excel-compatible export: CSV with .xls extension opens directly in Excel. */
  downloadExcel(filename, rows, headers) {
    const csv = this.toCSV(rows, headers);
    const blob = new Blob([csv], { type: 'application/vnd.ms-excel' });
    this._download(blob, filename.endsWith('.xls') ? filename : `${filename}.xls`);
  },

  /** Opens a formatted, printable window; user chooses "Save as PDF". */
  downloadPDF(title, htmlBody) {
    const win = window.open('', '_blank');
    win.document.write(`
      <html>
        <head>
          <title>${title}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
            h1 { font-size: 18px; margin-bottom: 12px; }
            table { width: 100%; border-collapse: collapse; font-size: 12px; }
            th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
            th { background: #F5921E; color: #fff; }
          </style>
        </head>
        <body>
          <h1>${title}</h1>
          ${htmlBody}
        </body>
      </html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 300);
  },

  tableToHTML(rows, headers, labels) {
    const head = `<tr>${headers.map((h, i) => `<th>${labels ? labels[i] : h}</th>`).join('')}</tr>`;
    const body = rows.map((r) => `<tr>${headers.map((h) => `<td>${r[h] ?? ''}</td>`).join('')}</tr>`).join('');
    return `<table>${head}${body}</table>`;
  },

  _download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
};

window.ExportUtil = ExportUtil;
