/**
 * printer.js
 * ESC/POS printing adapter for 2"/3" Bluetooth thermal printers.
 *
 * Primary path: Web Bluetooth API (works in Chrome on Android; most
 * cheap thermal printers expose a serial-profile-like GATT service).
 *
 * Fallback path ("bridge-friendly adapter"): since Web Bluetooth is not
 * available on iOS/Safari and many printers use classic Bluetooth SPP
 * (not BLE GATT), we also support handing off a raw ESC/POS byte buffer
 * to a companion bridge app via:
 *   1. A custom URL scheme (rawbt://, escpos://) commonly used by
 *      Android RawBT-style print bridges, or
 *   2. window.AndroidPrintBridge.print(base64Data) if the app is wrapped
 *      in a WebView that injects that interface, or
 *   3. Manual "Download .bin/.txt" of the ESC/POS payload for use with
 *      any external print utility.
 */

const ESC = 0x1b, GS = 0x1d;

const ESCPOS = {
  init: () => [ESC, 0x40],
  alignLeft: () => [ESC, 0x61, 0x00],
  alignCenter: () => [ESC, 0x61, 0x01],
  alignRight: () => [ESC, 0x61, 0x02],
  boldOn: () => [ESC, 0x45, 0x01],
  boldOff: () => [ESC, 0x45, 0x00],
  // GS ! n : high nibble (bits 4-7) = height magnification, low nibble (bits 0-3) = width magnification.
  // These were previously swapped, which made "medium" print wide-but-flat text instead of taller text.
  sizeNormal: () => [GS, 0x21, 0x00],
  sizeDoubleHeight: () => [GS, 0x21, 0x10], // taller only
  sizeDoubleWidth: () => [GS, 0x21, 0x01],  // wider only
  sizeDoubleBoth: () => [GS, 0x21, 0x11],   // taller + wider
  cut: () => [GS, 0x56, 0x42, 0x00],
  feed: (n = 1) => [ESC, 0x64, n],
  text(str) {
    return Array.from(new TextEncoder().encode(str));
  },
  line(str = '') {
    return [...this.text(str), 0x0a];
  }
};

function alignCmd(align) {
  if (align === 'center') return ESCPOS.alignCenter();
  if (align === 'right') return ESCPOS.alignRight();
  return ESCPOS.alignLeft();
}

function sizeCmd(size) {
  if (size === 'medium') return ESCPOS.sizeDoubleHeight();
  if (size === 'large') return ESCPOS.sizeDoubleBoth();
  return ESCPOS.sizeNormal();
}

function getPaperWidthMm(shop) {
  const legacyWidths = { '2in': 58, '3in': 76, '4in': 100 };
  const saved = shop && (shop.paperWidthMm ?? legacyWidths[shop.paperWidth]);
  const width = Number(saved);
  return Number.isFinite(width) ? Math.max(50, Math.min(100, Math.round(width))) : 76;
}

function getPaperProfile(shop) {
  // 50–100 mm rolls provide about 28–56 printable characters in the
  // standard thermal-printer font used by this receipt layout.
  const width = Math.max(28, Math.min(56, Math.round(getPaperWidthMm(shop) * 0.56)));
  const snoLen = 4;
  const priceLen = Math.max(7, Math.round(width * 0.18));
  const qtyLen = Math.max(4, Math.round(width * 0.10));
  const totalLen = Math.max(8, Math.round(width * 0.20));
  const itemLen = Math.max(4, width - snoLen - priceLen - qtyLen - totalLen - 4);
  return { width, snoLen, itemLen, priceLen, qtyLen, totalLen };
}

function padCol(str, len, alignRight) {
  str = String(str);
  if (str.length > len) str = str.slice(0, len);
  return alignRight ? str.padStart(len, ' ') : str.padEnd(len, ' ');
}

function fmt2(n) {
  return Number(n || 0).toFixed(2);
}

/**
 * Builds the receipt as a flat list of line objects — this is the single
 * source of truth for what actually prints, used both to generate the
 * ESC/POS byte stream and to draw the on-screen Print Preview, so the
 * preview always matches the real output (v3 "cash bill" style, modeled
 * on the shop's existing register receipt format).
 *   { text, align: 'left'|'center'|'right', bold, big, sep }
 */
function buildReceiptLines(bill, shop) {
  shop = shop || {};
  const profile = getPaperProfile(shop);
  const sep = () => ({ sep: true, width: profile.width });
  const lines = [];

  const d = new Date(bill.date);
  const dateStr = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  const timeStr = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

  receiptTextLines(shop.customHeaderText, profile.width).forEach((text) => {
    lines.push({ text, align: 'center', section: 'header' });
  });
  lines.push({ text: `DT: ${dateStr} @ ${timeStr}   BILL NO: ${bill.billNo}`, align: 'left', section: 'header' });
  if (bill.customerName) {
    lines.push({ text: `Customer: ${bill.customerName}`, align: 'left', section: 'header' });
    if (bill.customerPhone) lines.push({ text: `Ph: ${bill.customerPhone}`, align: 'left', section: 'header' });
    if (bill.customerAddress) lines.push({ text: bill.customerAddress, align: 'left', section: 'header' });
  }
  lines.push(sep());

  lines.push({
    text: padCol('Sl', profile.snoLen, false) + ' ' +
      padCol('ITEM', profile.itemLen, false) + ' ' +
      padCol('PRICE', profile.priceLen, true) + ' ' +
      padCol('QTY', profile.qtyLen, true) + ' ' +
      padCol('TOTAL', profile.totalLen, true),
    align: 'left'
  });
  lines.push(sep());

  bill.items.forEach((item, i) => {
    lines.push({
      text: padCol(i + 1, profile.snoLen, false) + ' ' +
        padCol(item.name || '', profile.itemLen, false) + ' ' +
        padCol(fmt2(item.rate), profile.priceLen, true) + ' ' +
        padCol(item.qty, profile.qtyLen, true) + ' ' +
        padCol(fmt2(item.total), profile.totalLen, true),
      align: 'left'
    });
  });
  lines.push(sep());

  const subtotalLabel = padCol('SUBTOTAL', profile.snoLen + profile.itemLen + profile.priceLen + profile.qtyLen, false);
  lines.push({ text: subtotalLabel + padCol(fmt2(bill.grandTotal), profile.totalLen, true), align: 'left' });
  lines.push({ text: `NITEMS: ${bill.items.length}   NQTY: ${fmt2(bill.totalQty)}`, align: 'left' });
  lines.push(sep());

  lines.push({ text: `GRAND TOTAL: Rs ${fmt2(bill.grandTotal)}`, align: 'center', bold: true, section: 'grandtotal' });
  lines.push(sep());

  receiptTextLines(shop.customFooterText, profile.width).forEach((text) => {
    lines.push({ text, align: shop.footerAlign || 'center', section: 'header' });
  });

  return lines;
}

function receiptTextLines(value, width, maxLines = 4) {
  const result = [];
  String(value || '').replace(/\r/g, '').split('\n').forEach((source) => {
    let remaining = source.trim();
    while (remaining && result.length < maxLines) {
      if (remaining.length <= width) {
        result.push(remaining);
        break;
      }
      const breakAt = remaining.lastIndexOf(' ', width);
      const cut = breakAt > 0 ? breakAt : width;
      result.push(remaining.slice(0, cut).trim());
      remaining = remaining.slice(cut).trim();
    }
  });
  return result;
}

function buildReceiptBytes(bill, shop) {
  shop = shop || {};
  const bytes = [];
  const push = (arr) => bytes.push(...arr);
  const lines = buildReceiptLines(bill, shop);

  push(ESCPOS.init());

  lines.forEach((l) => {
    if (l.sep) {
      push(alignCmd('left'));
      push(ESCPOS.sizeNormal());
      push(ESCPOS.line('-'.repeat(l.width)));
      return;
    }
    push(alignCmd(l.align || 'left'));
    if (l.bold) push(ESCPOS.boldOn());

    // Only scale height, never width — doubling character width on a single
    // text line (e.g. the old 'large'/double-both grand total) overflows
    // the physical paper and gets cut off or wrapped by the printer.
    const sizeName = (l.section === 'header' || l.section === 'grandtotal') ? 'medium' : 'normal';
    push(sizeCmd(sizeName));

    push(ESCPOS.line(l.text));
    push(ESCPOS.sizeNormal());
    if (l.bold) push(ESCPOS.boldOff());
  });

  push(ESCPOS.feed(3));
  push(ESCPOS.cut());

  return new Uint8Array(bytes);
}

const Printer = {
  device: null,
  characteristic: null,

  // Common ESC/POS printer BLE service/characteristic UUIDs (varies by vendor,
  // many clones use this generic serial-port-profile-over-BLE UUID pair).
  SERVICE_UUID: '000018f0-0000-1000-8000-00805f9b34fb',
  CHAR_UUID: '00002af1-0000-1000-8000-00805f9b34fb',

  isWebBluetoothSupported() {
    return 'bluetooth' in navigator;
  },

  async connect() {
    if (!this.isWebBluetoothSupported()) {
      throw new Error('Web Bluetooth not supported on this browser/device.');
    }
    this.device = await navigator.bluetooth.requestDevice({
      filters: [{ services: [this.SERVICE_UUID] }],
      optionalServices: [this.SERVICE_UUID]
    });
    const server = await this.device.gatt.connect();
    const service = await server.getPrimaryService(this.SERVICE_UUID);
    this.characteristic = await service.getCharacteristic(this.CHAR_UUID);

    const settings = await DB.get(DB.STORES.settings, 'shop');
    settings.printerDeviceId = this.device.id;
    settings.printerDeviceName = this.device.name;
    await DB.put(DB.STORES.settings, settings);

    return this.device;
  },

  async disconnect() {
    if (this.device && this.device.gatt.connected) this.device.gatt.disconnect();
    this.device = null;
    this.characteristic = null;
  },

  async printViaBluetooth(bytes) {
    if (!this.characteristic) await this.connect();
    const CHUNK = 180; // BLE MTU-safe chunk size
    for (let i = 0; i < bytes.length; i += CHUNK) {
      const chunk = bytes.slice(i, i + CHUNK);
      await this.characteristic.writeValue(chunk);
      // small delay helps cheap printers keep up
      await new Promise((r) => setTimeout(r, 20));
    }
  },

  /** Bridge-friendly fallback: hands raw bytes to an external print bridge app. */
  printViaBridge(bytes) {
    const b64 = btoa(String.fromCharCode(...bytes));

    if (window.AndroidPrintBridge && typeof window.AndroidPrintBridge.print === 'function') {
      window.AndroidPrintBridge.print(b64);
      return 'android-bridge';
    }

    // RawBT-style intent URL (installed separately on Android; widely used
    // for exactly this "web app -> Bluetooth thermal printer" gap).
    try {
      window.location.href = `rawbt:base64,${b64}`;
      return 'rawbt-intent';
    } catch (e) {
      // ignore and fall through to download
    }

    // Last-resort fallback: download the raw ESC/POS payload.
    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bill-${Date.now()}.escpos`;
    a.click();
    URL.revokeObjectURL(url);
    return 'download';
  },

  /** Main entry point used by the UI. */
  async printBill(bill, shop) {
    const bytes = buildReceiptBytes(bill, shop);
    if (this.isWebBluetoothSupported()) {
      try {
        await this.printViaBluetooth(bytes);
        return { method: 'bluetooth' };
      } catch (err) {
        console.warn('Bluetooth print failed, falling back to bridge:', err);
      }
    }
    const method = this.printViaBridge(bytes);
    return { method };
  }
};

window.Printer = Printer;
