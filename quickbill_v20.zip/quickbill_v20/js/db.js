/**
 * db.js
 * IndexedDB schema + generic CRUD helpers for Quick Bill.
 *
 * Stores:
 *  - items        : inventory items
 *  - customers     : customer records
 *  - bills         : sales bills (with embedded line items)
 *  - billItems     : denormalized line items (fast reporting/item-wise queries)
 *  - payments      : payment records against bills / customer balances
 *  - users         : login accounts (admin/staff)
 *  - settings      : key/value app settings (shop name, GST no, printer, counters)
 *  - stockLedger   : stock in/out audit trail
 */

const DB_NAME = 'quickbill_db';
const DB_VERSION = 1;

const STORES = {
  items: 'items',
  customers: 'customers',
  bills: 'bills',
  billItems: 'billItems',
  payments: 'payments',
  users: 'users',
  settings: 'settings',
  stockLedger: 'stockLedger'
};

let dbInstance = null;

function openDB() {
  return new Promise((resolve, reject) => {
    if (dbInstance) return resolve(dbInstance);

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // items: inventory
      if (!db.objectStoreNames.contains(STORES.items)) {
        const items = db.createObjectStore(STORES.items, { keyPath: 'id', autoIncrement: true });
        items.createIndex('barcode', 'barcode', { unique: false });
        items.createIndex('name', 'name', { unique: false });
        items.createIndex('category', 'category', { unique: false });
      }

      // customers
      if (!db.objectStoreNames.contains(STORES.customers)) {
        const customers = db.createObjectStore(STORES.customers, { keyPath: 'id', autoIncrement: true });
        customers.createIndex('phone', 'phone', { unique: false });
        customers.createIndex('name', 'name', { unique: false });
      }

      // bills
      if (!db.objectStoreNames.contains(STORES.bills)) {
        const bills = db.createObjectStore(STORES.bills, { keyPath: 'id', autoIncrement: true });
        bills.createIndex('billNo', 'billNo', { unique: true });
        bills.createIndex('date', 'date', { unique: false });
        bills.createIndex('customerId', 'customerId', { unique: false });
        bills.createIndex('status', 'status', { unique: false }); // draft/completed/void/returned
        bills.createIndex('paymentStatus', 'paymentStatus', { unique: false }); // paid/unpaid/partial
      }

      // billItems (denormalized, for fast item-wise reports)
      if (!db.objectStoreNames.contains(STORES.billItems)) {
        const billItems = db.createObjectStore(STORES.billItems, { keyPath: 'id', autoIncrement: true });
        billItems.createIndex('billId', 'billId', { unique: false });
        billItems.createIndex('itemId', 'itemId', { unique: false });
        billItems.createIndex('date', 'date', { unique: false });
      }

      // payments
      if (!db.objectStoreNames.contains(STORES.payments)) {
        const payments = db.createObjectStore(STORES.payments, { keyPath: 'id', autoIncrement: true });
        payments.createIndex('billId', 'billId', { unique: false });
        payments.createIndex('customerId', 'customerId', { unique: false });
        payments.createIndex('date', 'date', { unique: false });
      }

      // users
      if (!db.objectStoreNames.contains(STORES.users)) {
        const users = db.createObjectStore(STORES.users, { keyPath: 'id', autoIncrement: true });
        users.createIndex('username', 'username', { unique: true });
      }

      // settings (key/value)
      if (!db.objectStoreNames.contains(STORES.settings)) {
        db.createObjectStore(STORES.settings, { keyPath: 'key' });
      }

      // stockLedger
      if (!db.objectStoreNames.contains(STORES.stockLedger)) {
        const ledger = db.createObjectStore(STORES.stockLedger, { keyPath: 'id', autoIncrement: true });
        ledger.createIndex('itemId', 'itemId', { unique: false });
        ledger.createIndex('date', 'date', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = event.target.result;
      resolve(dbInstance);
    };

    request.onerror = (event) => reject(event.target.error);
  });
}

function tx(storeName, mode = 'readonly') {
  return openDB().then((db) => db.transaction(storeName, mode).objectStore(storeName));
}

const DB = {
  STORES,

  add(storeName, value) {
    return tx(storeName, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.add(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  },

  put(storeName, value) {
    return tx(storeName, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  },

  get(storeName, key) {
    return tx(storeName).then((store) => new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  },

  getAll(storeName) {
    return tx(storeName).then((store) => new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  },

  getByIndex(storeName, indexName, value) {
    return tx(storeName).then((store) => new Promise((resolve, reject) => {
      const req = store.index(indexName).getAll(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  },

  delete(storeName, key) {
    return tx(storeName, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.delete(key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    }));
  },

  clear(storeName) {
    return tx(storeName, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.clear();
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    }));
  },

  // Full DB export for backup
  async exportAll() {
    const dump = {};
    for (const name of Object.values(STORES)) {
      dump[name] = await DB.getAll(name);
    }
    dump._meta = { exportedAt: new Date().toISOString(), version: DB_VERSION };
    return dump;
  },

  // Full DB restore from a backup object (overwrites existing stores)
  async importAll(dump) {
    for (const name of Object.values(STORES)) {
      if (!dump[name]) continue;
      await DB.clear(name);
      const store = await tx(name, 'readwrite');
      await new Promise((resolve, reject) => {
        const t = store.transaction;
        dump[name].forEach((row) => store.put(row));
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
    }
    return true;
  },

  async seedDefaultsIfEmpty() {
    const users = await DB.getAll(STORES.users);
    if (users.length === 0) {
      await DB.add(STORES.users, { username: 'admin', pin: '1234', role: 'admin', name: 'Owner' });
      await DB.add(STORES.users, { username: 'staff', pin: '0000', role: 'staff', name: 'Staff' });
    }
    const settings = await DB.get(STORES.settings, 'shop');
    if (!settings) {
      await DB.put(STORES.settings, {
        key: 'shop',
        shopName: 'Arun Traders',
        address: '',
        phone: '',
        gstNo: '',
        billPrefix: 'INV',
        nextBillSeq: 1,
        printerDeviceId: null,
        paperWidthMm: 76,
        customHeaderText: '',
        customFooterText: '',
        footerAlign: 'center'
      });
    }

    const items = await DB.getAll(STORES.items);
    if (items.length === 0) {
      const sampleItems = [
        { name: 'Basmati Rice 1kg', barcode: '8901030100001', category: 'Grocery', purchaseRate: 70, saleRate: 90, stock: 120, reorderLevel: 20 },
        { name: 'Toor Dal 1kg', barcode: '8901030100002', category: 'Grocery', purchaseRate: 110, saleRate: 135, stock: 60, reorderLevel: 15 },
        { name: 'Sunflower Oil 1L', barcode: '8901030100003', category: 'Grocery', purchaseRate: 140, saleRate: 165, stock: 40, reorderLevel: 10 },
        { name: 'Sugar 1kg', barcode: '8901030100004', category: 'Grocery', purchaseRate: 40, saleRate: 48, stock: 100, reorderLevel: 20 },
        { name: 'Wheat Flour 1kg', barcode: '8901030100005', category: 'Grocery', purchaseRate: 38, saleRate: 50, stock: 80, reorderLevel: 15 },
        { name: 'Parle-G Biscuit', barcode: '8901030100006', category: 'Snacks', purchaseRate: 8, saleRate: 10, stock: 300, reorderLevel: 50 },
        { name: 'Amul Milk 500ml', barcode: '8901030100007', category: 'Dairy', purchaseRate: 24, saleRate: 28, stock: 80, reorderLevel: 20 },
        { name: 'Tata Salt 1kg', barcode: '8901030100008', category: 'Grocery', purchaseRate: 18, saleRate: 22, stock: 90, reorderLevel: 20 }
      ];
      for (const item of sampleItems) await DB.add(STORES.items, item);
    }

    const customers = await DB.getAll(STORES.customers);
    if (customers.length === 0) {
      const sampleCustomers = [
        { name: 'Ramesh Kumar', phone: '9880011223', address: 'Jayanagar, Bangalore', balance: 0 },
        { name: 'Priya Shah', phone: '9880033445', address: 'Indiranagar, Bangalore', balance: 250 },
        { name: 'Suresh Traders (Wholesale)', phone: '9880099887', address: 'KR Market, Bangalore', balance: 1800 },
        { name: 'Lakshmi Devi', phone: '9880055667', address: 'Basavanagudi, Bangalore', balance: 0 },
        { name: 'Manoj Enterprises', phone: '9880077889', address: 'Malleshwaram, Bangalore', balance: 500 }
      ];
      for (const c of sampleCustomers) await DB.add(STORES.customers, c);
    }
  }
};

window.DB = DB;
window.openDB = openDB;
