/**
 * billing.js
 * Core billing logic: cart management, bill save/edit/void/return,
 * stock deduction, and sales reporting queries.
 */

const Billing = {
  cart: [], // { itemId, name, qty, rate, total }

  addLine(item, qty, rate) {
    qty = Number(qty) || 0;
    rate = Number(rate) || 0;
    if (qty <= 0) throw new Error('Quantity must be greater than 0');

    const total = +(qty * rate).toFixed(2);
    this.cart.push({
      itemId: item ? item.id : null,
      name: item ? item.name : 'Item',
      barcode: item ? item.barcode : '',
      qty,
      rate,
      total
    });
    return this.cart[this.cart.length - 1];
  },

  updateLine(index, qty, rate) {
    const line = this.cart[index];
    if (!line) return;
    line.qty = Number(qty) || line.qty;
    line.rate = Number(rate) || line.rate;
    line.total = +(line.qty * line.rate).toFixed(2);
  },

  removeLine(index) {
    this.cart.splice(index, 1);
  },

  clearCart() {
    this.cart = [];
  },

  totals() {
    const totalQty = this.cart.reduce((s, l) => s + l.qty, 0);
    const totalAmount = this.cart.reduce((s, l) => s + l.total, 0);
    return { totalQty, totalAmount: +totalAmount.toFixed(2) };
  },

  async nextBillNo() {
    const settings = await DB.get(DB.STORES.settings, 'shop');
    const seq = settings.nextBillSeq || 1;
    settings.nextBillSeq = seq + 1;
    await DB.put(DB.STORES.settings, settings);
    return `${settings.billPrefix || 'INV'}-${String(seq).padStart(4, '0')}`;
  },

  /**
   * Save current cart as a completed bill.
   * Deducts stock and writes billItems + stockLedger rows.
   */
  /**
   * Ensures every cart line is linked to a real inventory item. Lines added
   * via "Use as manual entry" (typed a name, no catalog match) get a new
   * inventory item created automatically — matched by exact name if one
   * already exists (so re-using the same manual name doesn't duplicate),
   * otherwise created fresh with that name and rate as both purchase and
   * sale price. Lines with no name at all (pure keypad qty+rate, never
   * named) are left untouched since there's nothing meaningful to file
   * them under.
   */
  async autoAddManualItemsToInventory() {
    const addedNames = [];
    const namesNeedingCheck = this.cart.some((l) => !l.itemId && (l.name || '').trim() && l.name.trim() !== 'Item');
    const allItems = namesNeedingCheck ? await DB.getAll(DB.STORES.items) : [];

    for (const line of this.cart) {
      if (line.itemId) continue;
      const name = (line.name || '').trim();
      if (!name || name === 'Item') continue;

      const match = allItems.find((it) => it.name.trim().toLowerCase() === name.toLowerCase());

      if (match) {
        line.itemId = match.id;
      } else {
        const newItem = {
          name,
          barcode: '',
          category: '',
          purchaseRate: line.rate,
          saleRate: line.rate,
          stock: 0,
          reorderLevel: 0
        };
        const newId = await DB.add(DB.STORES.items, newItem);
        line.itemId = newId;
        allItems.push({ id: newId, name });
        addedNames.push(name);
      }
    }
    return addedNames;
  },

  async saveBill({ customerId = null, paymentStatus = 'paid', paymentMode = 'cash', discount = 0 }) {
    if (this.cart.length === 0) throw new Error('Cart is empty');

    const newInventoryItems = await this.autoAddManualItemsToInventory();

    const { totalQty, totalAmount } = this.totals();
    const billNo = await this.nextBillNo();
    const now = new Date().toISOString();

    let customerSnapshot = {};
    if (customerId) {
      const customer = await DB.get(DB.STORES.customers, customerId);
      if (customer) {
        customerSnapshot = {
          customerName: customer.name,
          customerPhone: customer.phone || '',
          customerAddress: customer.address || ''
        };
      }
    }

    const bill = {
      billNo,
      date: now,
      customerId,
      ...customerSnapshot,
      items: this.cart.slice(),
      totalQty,
      subTotal: totalAmount,
      discount: Number(discount) || 0,
      grandTotal: +(totalAmount - (Number(discount) || 0)).toFixed(2),
      paymentStatus, // paid | unpaid | partial
      paymentMode,   // cash | upi | card | credit
      status: 'completed' // completed | void | returned
    };

    const billId = await DB.add(DB.STORES.bills, bill);

    for (const line of this.cart) {
      await DB.add(DB.STORES.billItems, {
        billId,
        itemId: line.itemId,
        name: line.name,
        qty: line.qty,
        rate: line.rate,
        total: line.total,
        date: now
      });

      if (line.itemId) {
        const item = await DB.get(DB.STORES.items, line.itemId);
        if (item) {
          item.stock = (Number(item.stock) || 0) - line.qty;
          await DB.put(DB.STORES.items, item);
          await DB.add(DB.STORES.stockLedger, {
            itemId: line.itemId,
            change: -line.qty,
            reason: 'sale',
            billId,
            date: now
          });
        }
      }
    }

    if (customerId && paymentStatus !== 'paid') {
      const customer = await DB.get(DB.STORES.customers, customerId);
      if (customer) {
        customer.balance = (Number(customer.balance) || 0) + bill.grandTotal;
        await DB.put(DB.STORES.customers, customer);
      }
    }

    this.clearCart();
    return { ...bill, id: billId, newInventoryItems };
  },

  async voidBill(billId) {
    const bill = await DB.get(DB.STORES.bills, billId);
    if (!bill) throw new Error('Bill not found');
    if (bill.status === 'void') return bill;

    // restock items
    for (const line of bill.items) {
      if (line.itemId) {
        const item = await DB.get(DB.STORES.items, line.itemId);
        if (item) {
          item.stock = (Number(item.stock) || 0) + line.qty;
          await DB.put(DB.STORES.items, item);
          await DB.add(DB.STORES.stockLedger, {
            itemId: line.itemId,
            change: line.qty,
            reason: 'void',
            billId,
            date: new Date().toISOString()
          });
        }
      }
    }

    bill.status = 'void';
    await DB.put(DB.STORES.bills, bill);
    return bill;
  },

  async returnBill(billId, returnLines) {
    // returnLines: [{ itemId, qty }]
    const bill = await DB.get(DB.STORES.bills, billId);
    if (!bill) throw new Error('Bill not found');

    let returnAmount = 0;
    for (const rl of returnLines) {
      const line = bill.items.find((l) => l.itemId === rl.itemId);
      if (!line) continue;
      returnAmount += line.rate * rl.qty;

      if (rl.itemId) {
        const item = await DB.get(DB.STORES.items, rl.itemId);
        if (item) {
          item.stock = (Number(item.stock) || 0) + rl.qty;
          await DB.put(DB.STORES.items, item);
          await DB.add(DB.STORES.stockLedger, {
            itemId: rl.itemId,
            change: rl.qty,
            reason: 'return',
            billId,
            date: new Date().toISOString()
          });
        }
      }
    }

    bill.status = 'returned';
    bill.returnAmount = +(bill.returnAmount || 0) + returnAmount;
    await DB.put(DB.STORES.bills, bill);
    return bill;
  },

  async editBill(billId, updatedFields) {
    const bill = await DB.get(DB.STORES.bills, billId);
    if (!bill) throw new Error('Bill not found');
    Object.assign(bill, updatedFields);
    await DB.put(DB.STORES.bills, bill);
    return bill;
  },

  async deleteBill(billId) {
    await DB.delete(DB.STORES.bills, billId);
    const items = await DB.getByIndex(DB.STORES.billItems, 'billId', billId);
    for (const it of items) await DB.delete(DB.STORES.billItems, it.id);
  },

  // ---- Reporting ----

  async billsBetween(startISO, endISO) {
    const all = await DB.getAll(DB.STORES.bills);
    return all.filter((b) => b.date >= startISO && b.date <= endISO);
  },

  async dailySales(dateStr) {
    const start = `${dateStr}T00:00:00.000Z`;
    const end = `${dateStr}T23:59:59.999Z`;
    const bills = await this.billsBetween(start, end);
    const completed = bills.filter((b) => b.status === 'completed');
    return {
      billCount: completed.length,
      totalAmount: +completed.reduce((s, b) => s + b.grandTotal, 0).toFixed(2),
      totalQty: completed.reduce((s, b) => s + b.totalQty, 0)
    };
  },

  async monthlySales(year, month) {
    const all = await DB.getAll(DB.STORES.bills);
    const completed = all.filter((b) => {
      const d = new Date(b.date);
      return b.status === 'completed' && d.getFullYear() === year && d.getMonth() + 1 === month;
    });
    return {
      billCount: completed.length,
      totalAmount: +completed.reduce((s, b) => s + b.grandTotal, 0).toFixed(2),
      totalQty: completed.reduce((s, b) => s + b.totalQty, 0)
    };
  },

  async itemWiseSales(startISO, endISO) {
    const billItems = await DB.getAll(DB.STORES.billItems);
    const filtered = billItems.filter((bi) => bi.date >= startISO && bi.date <= endISO);
    const map = {};
    for (const bi of filtered) {
      const key = bi.itemId || bi.name;
      if (!map[key]) map[key] = { name: bi.name, qty: 0, amount: 0 };
      map[key].qty += bi.qty;
      map[key].amount += bi.total;
    }
    return Object.values(map);
  },

  async profitReport(startISO, endISO) {
    const billItems = await DB.getAll(DB.STORES.billItems);
    const filtered = billItems.filter((bi) => bi.date >= startISO && bi.date <= endISO);
    let revenue = 0, cost = 0;
    for (const bi of filtered) {
      revenue += bi.total;
      if (bi.itemId) {
        const item = await DB.get(DB.STORES.items, bi.itemId);
        if (item) cost += (Number(item.purchaseRate) || 0) * bi.qty;
      }
    }
    return { revenue: +revenue.toFixed(2), cost: +cost.toFixed(2), profit: +(revenue - cost).toFixed(2) };
  }
};

window.Billing = Billing;
